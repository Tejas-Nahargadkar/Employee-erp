import React from 'react'

export const Footer = () => {
  return (
    <div className='Footer'>
        <div className="footer-content">
            <li>
                <ul><h3>About Us</h3></ul>
                <ul>Lorem Ipsum</ul>
                <ul>Lorem Ipsum</ul>
                <ul>Lorem Ipsum</ul>
            </li>
            <li>
                <ul><h3>Services</h3></ul>
                <ul>Lorem Ipsum</ul>
                <ul>Lorem Ipsum</ul>
                <ul>Lorem Ipsum</ul>
            </li>
            <li>
                <ul><h3>Privacy</h3></ul>
                <ul>Lorem Ipsum</ul>
                <ul>Lorem Ipsum</ul>
                <ul>Lorem Ipsum</ul>
            </li>
            </div>  
    </div>
  )
}
