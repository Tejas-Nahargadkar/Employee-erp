import React from "react";
import "./worklogpage.css";

const WorkLogPage = () => {
  return (
    <div className="WorkLog">
      <h2>Daily Work Log</h2>

      <table>
        <tr>
          <th>Serial Number</th>
          <th>Project Name</th>
          <th>Task Title</th>
          <th>Due Date</th>
          <th>Estimated Hours</th>
          <th>Task Status</th>
        </tr>
        <tr>
          <td>
            <input type="number" name="Number" id="id-1" />
          </td>
          <td>
            <input
              type="text"
              name="Project Name"
              id="id-1"
              placeholder="Project Name"
            />
          </td>
          <td>
            <input
              type="text"
              name="Task Title"
              id="id-1"
              placeholder="Task Title"
            />
          </td>
          <td>
            <input
              className="Date"
              type="date"
              name="Due Date"
              id="id-1"
              placeholder="Due Date"
            />
          </td>
          <td>
            <input
              className="Time"
              type="time"
              name="Estimated Hours"
              id="id-1"
              placeholder="Estimated Hours"
            />
          </td>
          <td>
            <form className="Selection">
              <select className="Options" name="Task" id="id-1">
                <option className="op1" value="Select">
                  Select
                </option>
                <option className="op2" value="DONE">
                  DONE
                </option>
                <option className="op3" value="saab">
                  Working
                </option>
              </select>
            </form>
          </td>
        </tr>
        <tr>
          <td>
            <input type="number" name="Number" id="id-1" />
          </td>
          <td>
            <input
              type="text"
              name="Project Name"
              id="id-1"
              placeholder="Project Name"
            />
          </td>
          <td>
            <input
              type="text"
              name="Task Title"
              id="id-1"
              placeholder="Task Title"
            />
          </td>
          <td>
            <input
              className="Date"
              type="date"
              name="Due Date"
              id="id-1"
              placeholder="Due Date"
            />
          </td>
          <td>
            <input
              className="Time"
              type="time"
              name="Estimated Hours"
              id="id-1"
              placeholder="Estimated Hours"
            />
          </td>
          <td>
            <form>
              <select className="Options" name="Task" id="id-1">
                <option className="op1" value="Select">
                  Select
                </option>
                <option className="op2" value="DONE">
                  DONE
                </option>
                <option className="op3" value="saab">
                  Working
                </option>
              </select>
            </form>
          </td>
        </tr>
        <tr>
          <td>
            <input type="number" name="Number" id="id-1" />
          </td>
          <td>
            <input
              type="text"
              name="Project Name"
              id="id-1"
              placeholder="Project Name"
            />
          </td>
          <td>
            <input
              type="text"
              name="Task Title"
              id="id-1"
              placeholder="Task Title"
            />
          </td>
          <td>
            <input
              className="Date"
              type="date"
              name="Due Date"
              id="id-1"
              placeholder="Due Date"
            />
          </td>
          <td>
            <input
              className="Time"
              type="time"
              name="Estimated Hours"
              id="id-1"
              placeholder="Estimated Hours"
            />
          </td>
          <td>
            <form>
              <select className="Options" name="Task" id="id-1">
                <option className="op1" value="Select">
                  Select
                </option>
                <option className="op2" value="DONE">
                  DONE
                </option>
                <option className="op3" value="saab">
                  Working
                </option>
              </select>
            </form>
          </td>
        </tr>
        <tr>
          <td>
            <input type="number" name="Number" id="id-1" />
          </td>
          <td>
            <input
              type="text"
              name="Project Name"
              id="id-1"
              placeholder="Project Name"
            />
          </td>
          <td>
            <input
              type="text"
              name="Task Title"
              id="id-1"
              placeholder="Task Title"
            />
          </td>
          <td>
            <input
              className="Date"
              type="date"
              name="Due Date"
              id="id-1"
              placeholder="Due Date"
            />
          </td>
          <td>
            <input
              className="Time"
              type="time"
              name="Estimated Hours"
              id="id-1"
              placeholder="Estimated Hours"
            />
          </td>
          <td>
            <form>
              <select className="Options" name="Task" id="id-1">
                <option className="op1" value="Select">
                  Select
                </option>
                <option className="op2" value="DONE">
                  DONE
                </option>
                <option className="op3" value="saab">
                  Working
                </option>
              </select>
            </form>
          </td>
        </tr>
        <tr>
          <td>
            <input type="number" name="Number" id="id-1" />
          </td>
          <td>
            <input
              type="text"
              name="Project Name"
              id="id-1"
              placeholder="Project Name"
            />
          </td>
          <td>
            <input
              type="text"
              name="Task Title"
              id="id-1"
              placeholder="Task Title"
            />
          </td>
          <td>
            <input
              className="Date"
              type="date"
              name="Due Date"
              id="id-1"
              placeholder="Due Date"
            />
          </td>
          <td>
            <input
              className="Time"
              type="time"
              name="Estimated Hours"
              id="id-1"
              placeholder="Estimated Hours"
            />
          </td>
          <td>
            <form>
              <select className="Options" name="Task" id="id-1">
                <option className="op1" value="Select">
                  Select
                </option>
                <option className="op2" value="DONE">
                  DONE
                </option>
                <option className="op3" value="saab">
                  Working
                </option>
              </select>
            </form>
          </td>
        </tr>
        <tr>
          <td>
            <input type="number" name="Number" id="id-1" />
          </td>
          <td>
            <input
              type="text"
              name="Project Name"
              id="id-1"
              placeholder="Project Name"
            />
          </td>
          <td>
            <input
              type="text"
              name="Task Title"
              id="id-1"
              placeholder="Task Title"
            />
          </td>
          <td>
            <input
              className="Date"
              type="date"
              name="Due Date"
              id="id-1"
              placeholder="Due Date"
            />
          </td>
          <td>
            <input
              className="Time"
              type="time"
              name="Estimated Hours"
              id="id-1"
              placeholder="Estimated Hours"
            />
          </td>
          <td>
            <form>
              <select className="Options" name="Task" id="id-1">
                <option className="op1" value="Select">
                  Select
                </option>
                <option className="op2" value="DONE">
                  DONE
                </option>
                <option className="op3" value="saab">
                  Working
                </option>
              </select>
            </form>
          </td>
        </tr>
      </table>
      <div className="CommentBox">
      <textarea rows="8" cols="100" name="comment" form="usrform">
                    Remarks</textarea>
      </div>
      <div className="Buttons">
      <div className="btn1">
            <button className="button button1">Cancel</button>
          </div>

          <div className="btn2">
          <button type="submit" className="button button2">Save</button>
          </div>
      </div>
    </div>
  );
};

export default WorkLogPage;
